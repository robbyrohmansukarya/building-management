<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Welcome back
        <small>Pudyasto Adi Wibowo</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            beranda
        </div>
    </div>
</section>